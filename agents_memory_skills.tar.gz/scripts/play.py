"""Сыграть партию агентами.

    uv run python scripts/play.py --turns 20 --mode hierarchy
    uv run python scripts/play.py --turns 20 --mode single --no-memory --no-skills
"""

import argparse
import json
import logging
from pathlib import Path

from civ_agents.agents.government import Government
from civ_agents.config import load_settings, save_snapshot
from civ_agents.env.session import GameSession
from civ_agents.llm.openai_compat import OpenAICompatClient
from civ_agents.memory.episodic import EpisodicMemory
from civ_agents.memory.reflection import reflect
from civ_agents.memory.semantic import KnowledgeBase, make_knowledge
from civ_agents.observability.call_log import CallLog
from civ_agents.observability.run import Run
from civ_agents.observability.summary import load_calls, summarize

KNOWLEDGE_DIR = Path("knowledge")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--turns", type=int, default=None)
    parser.add_argument("--mode", choices=["hierarchy", "single"], default="hierarchy")
    parser.add_argument("--no-memory", action="store_true")
    parser.add_argument("--no-skills", action="store_true")
    parser.add_argument("--no-reflection", action="store_true")
    parser.add_argument("--name", default=None)
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    for noisy in ("httpx", "httpx2", "openai"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    settings = load_settings()
    if args.turns:
        settings.game.max_turns = args.turns
    variant = args.name or f"{args.mode}{'-nomem' if args.no_memory else ''}{'-noskills' if args.no_skills else ''}"
    run = Run.create(settings.paths.runs_dir, name=variant)
    save_snapshot(settings, run.config_path)

    llm = OpenAICompatClient(settings.llm.active, observer=CallLog.for_run(run, save_prompts=settings.logging.save_prompts))
    llm.health()
    print(f"Прогрев модели: {llm.warmup():.1f} с")

    memory = None if args.no_memory else EpisodicMemory(run.dir / "events.jsonl")
    knowledge = None if args.no_memory else make_knowledge(KnowledgeBase.from_dir(KNOWLEDGE_DIR))
    government = Government(llm, mode=args.mode, memory=memory, knowledge=knowledge,
                            use_skills=not args.no_skills, turn_budget_s=settings.limits.turn_time_budget_s)

    session = GameSession(settings, run)
    session.start()
    try:
        while not session.done:
            report = government.play_turn(session)
            print(f"Ход {report.turn}: {report.seconds:.1f} с, агенты {report.agents_called}, "
                  f"действий {report.actions_sent} (отклонено {report.actions_failed})")
    finally:
        results = session.close()

    state = session.view.state
    outcome = (f"turns {results['turns_played']}, cities {len(state.cities)}, units {len(state.units)}, "
               f"score {state.me.score}, techs known {len(state.known_techs)}, researching {state.me.researching}")
    metrics = {
        "variant": variant,
        "outcome": outcome,
        "cities": len(state.cities),
        "units": len(state.units),
        "score": state.me.score,
        "game": results,
        "government": government.stats(),
        "llm": summarize(load_calls(run.dir)),
    }
    if memory and not args.no_reflection:
        metrics["lessons"] = reflect(llm, memory.events, outcome, KNOWLEDGE_DIR / "lessons.md", run.run_id)
    (run.dir / "metrics.json").write_text(json.dumps(metrics, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(f"\nИтог: {outcome}")
    print(f"Метрики: {run.dir / 'metrics.json'}")


if __name__ == "__main__":
    main()
