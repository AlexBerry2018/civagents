# Lessons from previous games

## Initial lessons
- Found the first city on turn 1; waiting costs growth.
- Do not re-select the current research: it resets accumulated bulbs.
